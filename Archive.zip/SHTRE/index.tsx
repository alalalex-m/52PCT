/**
 * index.tsx — Entry Point for Anniversary Widget
 *
 * Running this script opens the settings page.
 * The widget (widget.tsx) runs separately on the home screen.
 */

import { Script } from "scripting"
import { presentSettings } from "./settings"

async function main() {
  // If called from widget tap, widgetParameter will be set
  if (Script.widgetParameter) {
    // Open settings from widget interaction
    await presentSettings()
  } else {
    // Normal launch: show settings
    await presentSettings()
  }
  Script.exit()
}

main()

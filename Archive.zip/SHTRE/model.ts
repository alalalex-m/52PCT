/**
 * model.ts — Anniversary Widget data model
 *
 * Handles date calculations, milestone detection, and config persistence.
 * Uses the App Group container so both the main app and widget extension
 * can read/write the configuration.
 */

// FileManager is a global API — no import needed.

// ─── Types ────────────────────────────────────────────────────────

export interface AnniversaryConfig {
  /** ISO date string (YYYY-MM-DD) of the relationship start. */
  startDate: string
  /** Optional label (e.g. "Tom & Jerry"). */
  label: string
  /** Which day-number milestones to celebrate. */
  milestoneDays: number[]
  /** Whether to announce annual anniversaries. */
  showAnniversaries: boolean
  /** Whether to announce monthly monthiversaries. */
  showMonthiversaries: boolean
  /** Whether to highlight fixed-date special days (520, 六一, 七夕). */
  showSpecialDates: boolean
}

export interface MilestoneEvent {
  kind: "milestone" | "monthiversary" | "anniversary" | "special_date"
  label: string
  /** The date of the event. */
  date: Date
  /** Human-readable description. */
  description: string
  /** Number of days until this event (0 = today). */
  daysUntil: number
}

// ─── Defaults ─────────────────────────────────────────────────────

const DEFAULT_CONFIG: AnniversaryConfig = {
  startDate: "2023-01-01",
  label: "We",
  milestoneDays: [99, 100, 520, 999, 1000, 1314, 9999],
  showAnniversaries: true,
  showMonthiversaries: true,
  showSpecialDates: true,
}

const CONFIG_FILENAME = "anniversary_config.json"

// ─── Persistence ──────────────────────────────────────────────────

function configPath(): string {
  return `${FileManager.appGroupDocumentsDirectory}/${CONFIG_FILENAME}`
}

export function loadConfig(): AnniversaryConfig {
  try {
    const raw = FileManager.readAsStringSync(configPath())
    return { ...DEFAULT_CONFIG, ...JSON.parse(raw) }
  } catch {
    return { ...DEFAULT_CONFIG }
  }
}

export function saveConfig(config: AnniversaryConfig): void {
  FileManager.writeAsStringSync(
    configPath(),
    JSON.stringify(config, null, 2),
  )
}

// ─── Date helpers ─────────────────────────────────────────────────

function daysBetween(a: Date, b: Date): number {
  const ms = b.getTime() - a.getTime()
  return Math.round(ms / 86400000)
}

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate())
}

export function parseISODate(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number)
  return new Date(y, m - 1, d)
}

function formatDate(d: Date): string {
  const months = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
  ]
  return `${months[d.getMonth()]} ${d.getDate()}`
}

function formatDateLong(d: Date): string {
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ]
  return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`
}

function ordinal(n: number): string {
  if (n >= 11 && n <= 13) return `${n}th`
  switch (n % 10) {
    case 1: return `${n}st`
    case 2: return `${n}nd`
    case 3: return `${n}rd`
    default: return `${n}th`
  }
}

// ─── Chinese special dates (approximate lunar → fixed) ────────────
// 七夕节: 7th day of 7th lunar month
// We approximate using a lookup table for 2024-2030.
// Falls back to August of the current year.

const QIXI_DATES: Record<number, { month: number; day: number }> = {
  2024: { month: 8, day: 10 },
  2025: { month: 8, day: 29 },
  2026: { month: 8, day: 19 },
  2027: { month: 8, day: 8 },
  2028: { month: 8, day: 26 },
  2029: { month: 8, day: 16 },
  2030: { month: 8, day: 5 },
}

function getQixiDate(year: number): Date {
  const known = QIXI_DATES[year]
  if (known) return new Date(year, known.month - 1, known.day)
  // Rough fallback
  return new Date(year, 7, 19) // August 19
}

// ─── Event computation ────────────────────────────────────────────

/**
 * Build a sorted (by date) list of all currently relevant events.
 * The first item is always the most urgent / today's highlight.
 */
export function computeEvents(config: AnniversaryConfig, now?: Date): MilestoneEvent[] {
  const today = startOfDay(now ?? new Date())
  const start = parseISODate(config.startDate)

  const daysSoFar = daysBetween(start, today)
  const events: MilestoneEvent[] = []

  // ── 1. Special fixed-date events ──────────────────────────────
  if (config.showSpecialDates) {
    const year = today.getFullYear()

    // 六一节 — June 1
    {
      const d = new Date(year, 5, 1)
      const diff = daysBetween(today, d)
      if (diff >= 0) {
        events.push({
          kind: "special_date",
          label: "Children's Day 🎈",
          date: d,
          description: "六一儿童节",
          daysUntil: diff,
        })
      }
    }

    // 520 — May 20
    {
      const d = new Date(year, 4, 20)
      const diff = daysBetween(today, d)
      if (diff >= 0) {
        events.push({
          kind: "special_date",
          label: "520 💕",
          date: d,
          description: "May 20th — Love Day",
          daysUntil: diff,
        })
      }
    }

    // 七夕 — 7th day of 7th lunar month
    {
      const d = getQixiDate(year)
      const diff = daysBetween(today, d)
      if (diff >= 0) {
        events.push({
          kind: "special_date",
          label: "七夕节 🌙",
          date: d,
          description: "Chinese Valentine's Day",
          daysUntil: diff,
        })
      }
    }

    // Also check next year's special dates (if past this year)
    const nextYear = year + 1
    // May 20 next year
    {
      const d = new Date(nextYear, 4, 20)
      const diff = daysBetween(today, d)
      if (diff >= 0 && diff < 366) {
        events.push({
          kind: "special_date",
          label: "520 💕",
          date: d,
          description: "May 20th — Love Day",
          daysUntil: diff,
        })
      }
    }
    // 六一 next year
    {
      const d = new Date(nextYear, 5, 1)
      const diff = daysBetween(today, d)
      if (diff >= 0 && diff < 366) {
        events.push({
          kind: "special_date",
          label: "Children's Day 🎈",
          date: d,
          description: "六一儿童节",
          daysUntil: diff,
        })
      }
    }
    // 七夕 next year
    {
      const d = getQixiDate(nextYear)
      const diff = daysBetween(today, d)
      if (diff >= 0 && diff < 366) {
        events.push({
          kind: "special_date",
          label: "七夕节 🌙",
          date: d,
          description: "Chinese Valentine's Day",
          daysUntil: diff,
        })
      }
    }
  }

  // ── 2. Day-number milestones ──────────────────────────────────
  for (const milestone of config.milestoneDays) {
    if (daysSoFar >= milestone) continue // already passed
    const delta = milestone - daysSoFar
    const d = new Date(today.getTime() + delta * 86400000)
    events.push({
      kind: "milestone",
      label: `${milestone} Days 🎉`,
      date: d,
      description: `${milestone} days since we started`,
      daysUntil: delta,
    })
  }

  // ── 3. Monthly monthiversaries ────────────────────────────────
  if (config.showMonthiversaries) {
    const totalMonths =
      (today.getFullYear() - start.getFullYear()) * 12 +
      (today.getMonth() - start.getMonth())

    for (let i = 1; i <= 3; i++) {
      const m = totalMonths + i
      // Compute the anniversary day in month `m` from start
      let targetDay = start.getDate()
      const targetMonth = (start.getMonth() + m) % 12
      const targetYear =
        start.getFullYear() + Math.floor((start.getMonth() + m) / 12)

      // Clamp to last day of target month
      const lastDay = new Date(targetYear, targetMonth + 1, 0).getDate()
      if (targetDay > lastDay) targetDay = lastDay

      const d = new Date(targetYear, targetMonth, targetDay)
      const diff = daysBetween(today, d)
      if (diff >= 0) {
        events.push({
          kind: "monthiversary",
          label: `${ordinal(m)} Monthiversary`,
          date: d,
          description: `${m} months together`,
          daysUntil: diff,
        })
      }
    }
  }

  // ── 4. Annual anniversaries ───────────────────────────────────
  if (config.showAnniversaries) {
    const years = today.getFullYear() - start.getFullYear()
    // Add this year's anniversary (if upcoming / today)
    {
      let targetDay = start.getDate()
      const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate()
      // We want the anniversary date in the current year
      const annivMonth = start.getMonth()
      const annivYear = today.getFullYear()
      const lastDayOfMonth = new Date(annivYear, annivMonth + 1, 0).getDate()
      if (targetDay > lastDayOfMonth) targetDay = lastDayOfMonth
      const d = new Date(annivYear, annivMonth, targetDay)
      const diff = daysBetween(today, d)
      if (diff >= 0 && years >= 1) {
        events.push({
          kind: "anniversary",
          label: `${ordinal(years)} Anniversary 💍`,
          date: d,
          description: `${years} years together`,
          daysUntil: diff,
        })
      }
    }
    // Next year's anniversary (always show if within 366 days)
    if (daysSoFar >= 0) {
      const nextYear = today.getFullYear() + 1
      let targetDay = start.getDate()
      const lastDayOfMonth = new Date(nextYear, start.getMonth() + 1, 0).getDate()
      if (targetDay > lastDayOfMonth) targetDay = lastDayOfMonth
      const d = new Date(nextYear, start.getMonth(), targetDay)
      const diff = daysBetween(today, d)
      if (diff >= 0 && diff < 367) {
        events.push({
          kind: "anniversary",
          label: `${ordinal(years + 1)} Anniversary 💍`,
          date: d,
          description: `${years + 1} years together`,
          daysUntil: diff,
        })
      }
    }
  }

  // Sort by daysUntil ascending
  events.sort((a, b) => a.daysUntil - b.daysUntil)

  return events
}

/**
 * Get a label for what "today" is, if anything special.
 */
export function getTodayLabel(events: MilestoneEvent[]): string | null {
  for (const e of events) {
    if (e.daysUntil === 0) {
      return e.description
    }
  }
  return null
}

/**
 * Countdown string.
 */
export function formatCountdown(days: number): string {
  if (days === 0) return "Today! 🎉"
  if (days === 1) return "Tomorrow 🎯"
  if (days <= 30) return `${days} days away`
  const months = Math.floor(days / 30)
  const remaining = days % 30
  if (months < 12) {
    return remaining > 0
      ? `${months}mo ${remaining}d`
      : `${months} months`
  }
  const years = Math.floor(months / 12)
  const remMonths = months % 12
  return remMonths > 0
    ? `${years}y ${remMonths}mo`
    : `${years} years`
}

/**
 * How many days since start
 */
export function daysSinceStart(config: AnniversaryConfig, now?: Date): number {
  const today = startOfDay(now ?? new Date())
  const days = daysBetween(parseISODate(config.startDate), today)
  // Guard against absurd values from date calculation errors
  if (days < 0 || days > 100000 || isNaN(days)) return 0
  return days
}

/**
 * settings.tsx — Anniversary Widget Settings
 *
 * An iOS-native settings page for configuring:
 *   - Start date
 *   - Relationship label
 *   - Milestone day numbers
 *   - Toggles for special dates / monthiversaries / anniversaries
 *
 * Uses FileManager.appGroupDocumentsDirectory so the widget can read the config.
 */

import {
  Navigation,
  NavigationStack,
  List,
  Section,
  Text,
  TextField,
  DatePicker,
  Button,
  Toggle,
  Widget,
  useState,
} from "scripting"
import {
  loadConfig,
  saveConfig,
  parseISODate,
  type AnniversaryConfig,
} from "./model"

const DEFAULT_MILESTONES = [99, 100, 520, 999, 1000, 1314, 9999]

export async function presentSettings(): Promise<void> {
  await Navigation.present(<SettingsPage />)
}

function SettingsPage() {
  const dismiss = Navigation.useDismiss()
  const config = loadConfig()

  // Local state for editing
  // Use parseISODate (local-time constructor) to stay consistent
  // with the widget's date calculations, avoiding timezone mismatches
  const d = parseISODate(config.startDate)
  const [startDate, setStartDate] = useState(d.getTime() / 1000)
  const [label, setLabel] = useState(config.label)
  const [milestonesText, setMilestonesText] = useState(
    config.milestoneDays.join(", ")
  )
  const [showSpecial, setShowSpecial] = useState(config.showSpecialDates)
  const [showMonthly, setShowMonthly] = useState(config.showMonthiversaries)
  const [showAnnually, setShowAnnually] = useState(config.showAnniversaries)

  function handleSave() {
    // Parse milestones
    const milestones = milestonesText
      .split(",")
      .map((s: string) => parseInt(s.trim(), 10))
      .filter((n: number) => !isNaN(n) && n > 0)
      .sort((a: number, b: number) => a - b)

    const dateObj = new Date(startDate * 1000)
    const isoDate = `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}-${String(dateObj.getDate()).padStart(2, "0")}`

    const newConfig: AnniversaryConfig = {
      startDate: isoDate,
      label: label.trim() || "We",
      milestoneDays: milestones.length > 0 ? milestones : DEFAULT_MILESTONES,
      showAnniversaries: showAnnually,
      showMonthiversaries: showMonthly,
      showSpecialDates: showSpecial,
    }

    saveConfig(newConfig)
    // Force all widgets to reload immediately with the new config
    Widget.reloadAll()
    dismiss()
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="Anniversary Settings"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          confirmationAction: (
            <Button title="Save" action={handleSave} />
          ),
          cancellationAction: (
            <Button title="Close" action={dismiss} />
          ),
        }}
      >
        {/* ── Relationship ── */}
        <Section title="RELATIONSHIP">
          <DatePicker
            title="Start Date"
            value={startDate}
            onChanged={setStartDate}
            displayedComponents={["date"]}
          />
          <TextField
            title="Label"
            value={label}
            onChanged={setLabel}
            prompt="e.g. Tom & Jerry"
          />
        </Section>

        {/* ── Milestones ── */}
        <Section
          header={
            <Text font="caption" foregroundStyle="#8e8e93">
              DAY MILESTONES
            </Text>
          }
          footer={
            <Text font="caption" foregroundStyle="#8e8e93">
              Comma-separated numbers. Happy numbers like 520, 999, 1314, 9999 are pre-filled.
            </Text>
          }
        >
          <TextField
            title="Milestone Days"
            value={milestonesText}
            onChanged={setMilestonesText}
            prompt="99, 100, 520, 999, 1000, 1314, 9999"
          />
        </Section>

        {/* ── Toggles ── */}
        <Section title="EVENT TYPES">
          <Toggle
            title="Special Dates (520, 六一, 七夕)"
            value={showSpecial}
            onChanged={setShowSpecial}
          />
          <Toggle
            title="Monthly Monthiversaries"
            value={showMonthly}
            onChanged={setShowMonthly}
          />
          <Toggle
            title="Annual Anniversaries"
            value={showAnnually}
            onChanged={setShowAnnually}
          />
        </Section>

        {/* ── Preview info ── */}
        <Section title="WIDGET INFO">
          <Text font="footnote" foregroundStyle="#8e8e93">
            Add this widget to your Home Screen by long-pressing → Edit → Add Widget.
            Choose "AnniversaryWidget" from the Scripting section.
          </Text>
        </Section>
      </List>
    </NavigationStack>
  )
}

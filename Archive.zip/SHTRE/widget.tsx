/**
 * widget.tsx — Anniversary Widget
 *
 * Linear-inspired design with:
 *   - Dark background (#0a0a0d)
 *   - Accent purple (#5E6AD2)
 *   - Rounded font, monochrome typography
 *   - Clean separators, subtle badges
 *   - Priority: Today's events → Next milestone → Upcoming events
 *
 * Widget sizes:
 *   systemSmall (169×169pt)  — days count + single event highlight
 *   systemMedium (360×169pt) — days count + badge + today events + 2 upcoming
 *   systemLarge (360×379pt)  — full detail: days count + badge + today + 8 upcoming
 */

import {
  VStack, HStack, Text, Spacer, Divider, Widget,
} from "scripting"
import {
  loadConfig,
  computeEvents,
  getTodayLabel,
  formatCountdown,
  daysSinceStart,
  type MilestoneEvent,
} from "./model"

// ─── Colors ───────────────────────────────────────────────────────
const ACCENT = "#5E6AD2"
const FG = "#ffffff"
const FG_SECONDARY = "#8e8e93"
const FG_TERTIARY = "#636366"
const SUCCESS = "#30D158"
const SEPARATOR = "rgba(255,255,255,0.06)"
const BADGE_BG = "rgba(94,106,210,0.15)"

// ─── Widget entry ─────────────────────────────────────────────────

function AnniversaryWidgetView() {
  const config = loadConfig()
  const today = new Date()
  const events = computeEvents(config, today)
  const daysTotal = daysSinceStart(config, today)
  const todayEvent = getTodayLabel(events)
  const family = Widget.family

  const upcoming = events.filter((e: MilestoneEvent) => e.daysUntil > 0)

  if (family === "systemSmall") {
    return renderSmall(config, events, todayEvent, daysTotal, today)
  }
  if (family === "systemLarge") {
    return renderLarge(config, events, todayEvent, daysTotal, upcoming)
  }
  return renderMedium(config, events, todayEvent, daysTotal, upcoming)
}

// ─── Small widget (169×169) ───────────────────────────────────────
// Shows: days count + label + one highlight event (today or next)

function renderSmall(
  config: any,
  events: MilestoneEvent[],
  todayEvent: string | null,
  daysTotal: number,
  today: Date,
) {
  const next = events.length > 0 ? events[0] : null

  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      padding={14}
    >
      <Text
        font={32}
        fontWeight="bold"
        fontDesign="rounded"
        foregroundStyle={ACCENT}
        lineLimit={1}
      >
        {daysTotal}
      </Text>
      <Text
        font="caption2"
        fontWeight="medium"
        foregroundStyle={FG_SECONDARY}
        padding={{ bottom: 6 }}
        lineLimit={1}
      >
        days together
      </Text>

      <Divider />

      <Spacer minLength={4} />

      {todayEvent ? (
        <VStack alignment="leading" spacing={1}>
          <Text
            font="caption2"
            fontWeight="bold"
            foregroundStyle={SUCCESS}
          >
            ● Today
          </Text>
          <Text
            font="caption"
            fontWeight="medium"
            foregroundStyle={FG}
            lineLimit={2}
          >
            {todayEvent}
          </Text>
        </VStack>
      ) : next ? (
        <VStack alignment="leading" spacing={1}>
          <Text
            font="caption2"
            fontWeight="bold"
            foregroundStyle={ACCENT}
          >
            ● Next
          </Text>
          <Text
            font="caption"
            fontWeight="medium"
            foregroundStyle={FG}
            lineLimit={2}
          >
            {next.label}
          </Text>
          <Text
            font="caption2"
            foregroundStyle={FG_SECONDARY}
          >
            {formatCountdown(next.daysUntil)}
          </Text>
        </VStack>
      ) : null}
    </VStack>
  )
}

// ─── Medium widget (360×169) ──────────────────────────────────────
// Shows: compact header + today events + max 2 upcoming events

function renderMedium(
  config: any,
  events: MilestoneEvent[],
  todayEvent: string | null,
  daysTotal: number,
  upcoming: MilestoneEvent[],
) {
  const nextMilestone = events.find(e => e.kind === "milestone" && e.daysUntil > 0)
  const todayEvents = events.filter(e => e.daysUntil === 0)
  // Show at most 2 upcoming events to stay within bounds
  const maxUpcoming = upcoming.slice(0, 2)

  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      padding={14}
    >
      {/* Header: days count + optional milestone badge */}
      <HStack alignment="center" spacing={6}>
        <VStack alignment="leading" spacing={0}>
          <Text
            font={24}
            fontWeight="bold"
            fontDesign="rounded"
            foregroundStyle={ACCENT}
            lineLimit={1}
          >
            {daysTotal}
          </Text>
          <Text
            font="caption2"
            fontWeight="medium"
            foregroundStyle={FG_SECONDARY}
            lineLimit={1}
          >
            days with {config.label || "you"}
          </Text>
        </VStack>
        <Spacer />
        {nextMilestone && (
          <VStack
            alignment="trailing"
            spacing={1}
            background={BADGE_BG as any}
            padding={{ horizontal: 8, vertical: 4 }}
          >
            <Text
              font="caption2"
              fontWeight="bold"
              foregroundStyle={ACCENT}
              fontDesign="rounded"
              lineLimit={1}
            >
              {nextMilestone.label}
            </Text>
            <Text
              font="caption2"
              fontWeight="medium"
              foregroundStyle={FG_SECONDARY}
            >
              {formatCountdown(nextMilestone.daysUntil)}
            </Text>
          </VStack>
        )}
      </HStack>

      <Spacer minLength={4} />
      <Divider />
      <Spacer minLength={4} />

      {/* Today's events (compact, single line per event) */}
      {todayEvents.length > 0 && (
        <VStack
          alignment="leading"
          spacing={2}
          background={SUCCESS + "1A" as any}
          padding={{ horizontal: 8, vertical: 6 }}
        >
          <Text
            font="caption2"
            fontWeight="bold"
            foregroundStyle={SUCCESS}
          >
            ● Today
          </Text>
          {todayEvents.slice(0, 2).map((e, i) => (
            <HStack key={`today-${i}`} spacing={4}>
              <Text
                font="footnote"
                fontWeight="semibold"
                foregroundStyle={FG}
                lineLimit={1}
              >
                {e.label}
              </Text>
              <Text
                font="caption2"
                foregroundStyle={FG_SECONDARY}
                lineLimit={1}
              >
                {e.description}
              </Text>
            </HStack>
          ))}
        </VStack>
      )}

      {/* Upcoming events (max 2) */}
      {maxUpcoming.length > 0 && (
        <VStack alignment="leading" spacing={3} padding={{ top: 4 }}>
          {maxUpcoming.map((e, i) => (
            <EventRow key={`up-md-${i}`} event={e} compact />
          ))}
        </VStack>
      )}
    </VStack>
  )
}

// ─── Large widget (360×379) ───────────────────────────────────────
// Shows: full header + today events + up to 8 upcoming events

function renderLarge(
  config: any,
  events: MilestoneEvent[],
  todayEvent: string | null,
  daysTotal: number,
  upcoming: MilestoneEvent[],
) {
  const todayEvents = events.filter(e => e.daysUntil === 0)
  const nextMilestone = events.find(e => e.kind === "milestone" && e.daysUntil > 0)

  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      padding={16}
    >
      {/* Header */}
      <HStack alignment="center" spacing={10}>
        <VStack alignment="leading" spacing={0}>
          <Text
            font={32}
            fontWeight="bold"
            fontDesign="rounded"
            foregroundStyle={ACCENT}
            lineLimit={1}
          >
            {daysTotal}
          </Text>
          <Text
            font="footnote"
            fontWeight="medium"
            foregroundStyle={FG_SECONDARY}
            lineLimit={1}
          >
            days with {config.label || "you"}
          </Text>
        </VStack>
        <Spacer />
        {nextMilestone && (
          <VStack
            alignment="center"
            spacing={2}
            background={BADGE_BG as any}
            padding={{ horizontal: 12, vertical: 6 }}
          >
            <Text
              font="footnote"
              fontWeight="bold"
              foregroundStyle={ACCENT}
              fontDesign="rounded"
              lineLimit={1}
            >
              {nextMilestone.label}
            </Text>
            <Text
              font="caption2"
              foregroundStyle={FG_SECONDARY}
            >
              {formatCountdown(nextMilestone.daysUntil)}
            </Text>
          </VStack>
        )}
      </HStack>

      <Spacer minLength={8} />
      <Divider />
      <Spacer minLength={8} />

      {/* Today's events */}
      {todayEvents.length > 0 && (
        <VStack
          alignment="leading"
          spacing={4}
          background={SUCCESS + "1A" as any}
          padding={10}
        >
          <Text
            font="caption"
            fontWeight="bold"
            foregroundStyle={SUCCESS}
          >
            ● Today
          </Text>
          {todayEvents.map((e, i) => (
            <HStack key={`today-lg-${i}`} spacing={6}>
              <Text
                font="subheadline"
                fontWeight="semibold"
                foregroundStyle={FG}
                lineLimit={1}
              >
                {e.label}
              </Text>
              <Text
                font="footnote"
                foregroundStyle={FG_SECONDARY}
                lineLimit={1}
              >
                {e.description}
              </Text>
            </HStack>
          ))}
        </VStack>
      )}

      <Spacer minLength={8} />

      {/* Upcoming events */}
      <Text
        font="caption"
        fontWeight="bold"
        foregroundStyle={FG_TERTIARY}
        padding={{ bottom: 4 }}
      >
        UPCOMING
      </Text>

      <VStack alignment="leading" spacing={4}>
        {upcoming.slice(0, 8).map((e, i) => (
          <EventRow key={`up-lg-${i}`} event={e} />
        ))}
      </VStack>
    </VStack>
  )
}

// ─── Shared row ───────────────────────────────────────────────────

function EventRow({ event, compact }: { event: MilestoneEvent; compact?: boolean }) {
  const icon = kindIcon(event.kind)

  if (compact) {
    // Compact layout for medium widget
    return (
      <HStack
        alignment="center"
        spacing={6}
        frame={{ maxWidth: "infinity" }}
      >
        <Text font="caption2" foregroundStyle={ACCENT}>
          {icon}
        </Text>
        <Text
          font="footnote"
          fontWeight="semibold"
          foregroundStyle={FG}
          lineLimit={1}
        >
          {event.label}
        </Text>
        <Spacer />
        <Text
          font="caption2"
          fontWeight="medium"
          foregroundStyle={event.daysUntil <= 7 ? ACCENT : FG_TERTIARY}
          fontDesign="rounded"
        >
          {formatCountdown(event.daysUntil)}
        </Text>
      </HStack>
    )
  }

  return (
    <HStack
      alignment="center"
      spacing={8}
      frame={{ maxWidth: "infinity" }}
    >
      {/* Dot indicator */}
      <Text font="caption2" foregroundStyle={ACCENT}>
        {icon}
      </Text>

      <VStack alignment="leading" spacing={0}>
        <Text
          font="footnote"
          fontWeight="semibold"
          foregroundStyle={FG}
          lineLimit={1}
        >
          {event.label}
        </Text>
        <Text
          font="caption2"
          fontWeight="regular"
          foregroundStyle={FG_SECONDARY}
          lineLimit={1}
        >
          {event.description}
        </Text>
      </VStack>

      <Spacer />

      <VStack alignment="trailing" spacing={0}>
        <Text
          font="caption2"
          fontWeight="medium"
          foregroundStyle={event.daysUntil <= 7 ? ACCENT : FG_TERTIARY}
          fontDesign="rounded"
        >
          {formatCountdown(event.daysUntil)}
        </Text>
        <Text font="caption2" foregroundStyle={FG_TERTIARY}>
          {formatDateShort(event.date)}
        </Text>
      </VStack>
    </HStack>
  )
}

// ─── Helpers ──────────────────────────────────────────────────────

function kindIcon(kind: string): string {
  switch (kind) {
    case "milestone": return "◆"
    case "monthiversary": return "◈"
    case "anniversary": return "◇"
    case "special_date": return "●"
    default: return "·"
  }
}

function formatDateShort(d: Date): string {
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  return `${months[d.getMonth()]} ${d.getDate()}`
}

// ─── Widget.present ───────────────────────────────────────────────
// Use "atEnd" policy so iOS requests a new timeline when needed.
// Combined with Widget.reloadAll() called from settings after save,
// the widget will update immediately when config changes.

Widget.present(<AnniversaryWidgetView />, {
  reloadPolicy: { policy: "atEnd" },
})

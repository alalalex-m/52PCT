import { VStack, HStack, Text, Spacer, Button, Widget, Color, LinearGradient } from "scripting"
import { ToggleHabitIntent, CycleHabitIntent } from "./app_intents"
import { loadRecords, isCompleted, loadConfiguredHabits, readSelectedHabit, Records } from "./storage"

// =========================
// CONFIGURATION
// =========================

const DAYS = ["M", "T", "W", "T", "F", "S", "S"]

// =========================
// DATE HELPERS
// =========================

function sameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

function getWeekMonday(): Date {
  let today = new Date()
  let day = today.getDay()
  let diff = day === 0 ? -6 : 1 - day
  let monday = new Date(today)
  monday.setDate(today.getDate() + diff)
  monday.setHours(0, 0, 0, 0)
  return monday
}

function dayIndex(date: Date): number {
  let d = date.getDay()
  return d === 0 ? 6 : d - 1
}

function toDateKey(date: Date): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, "0")
  const d = String(date.getDate()).padStart(2, "0")
  return `${y}-${m}-${d}`
}

// =========================
// WEEKLY VIEW (systemMedium)
// =========================

const NAME_WIDTH = 80

function WeeklyView({ records, habits }: { records: Records, habits: string[] }) {
  const monday = getWeekMonday()

  // Calculate cellWidth from actual widget width so it fits every device
  const paddingTotal = 64 // 16 on each side
  const cellWidth = Math.floor((Widget.displaySize.width - paddingTotal - NAME_WIDTH) / 7)

  return (
    <VStack
      padding={32}
      background={{
        colors: ["#111111", "#1c1c1e"],
        startPoint: { x: 0, y: 0 },
        endPoint: { x: 0, y: 1 },
      } as LinearGradient}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
    >
      {/* HEADER ROW */}
      <HStack>
        <Text frame={{ width: NAME_WIDTH, height: 20 }}>
          {habits.length === 0 ? "No habits" : ""}
        </Text>
        {DAYS.map(d => (
          <Text
            key={d}
            frame={{ width: cellWidth, height: 20 }}
            font={10}
            fontWeight="medium"
            foregroundStyle="#8E8E93"
          >
            {d}
          </Text>
        ))}
        <Spacer />
      </HStack>

      <Spacer minLength={1} />

      {/* HABIT ROWS */}
      <VStack spacing={5}>
      {habits.length === 0 ? (
        <HStack>
          <Text font={12} foregroundStyle="#48484A">
            Open Scripting → HabitTracker to add habits
          </Text>
        </HStack>
      ) : (
      habits.map(habit => (
        <HStack key={habit}>
          <Text
            frame={{ width: NAME_WIDTH, height: 32 }}
            font={12}
            foregroundStyle="#8E8E93"
          >
            {habit}
          </Text>
          {[0, 1, 2, 3, 4, 5, 6].map(i => {
            let currentDay = new Date(monday)
            currentDay.setDate(monday.getDate() + i)
            let dateKey = toDateKey(currentDay)
            let done = isCompleted(habit, dateKey, records)
            return (
              <Button
                key={i}
                buttonStyle="plain"
                frame={{ width: cellWidth, height: 32 }}
                intent={ToggleHabitIntent({ habitName: habit, dateString: dateKey })}
              >
                <Text
                  font={10}
                  foregroundStyle={done ? "#FF453A" : "#48484A"}
                >
                  {done ? "●" : "○"}
                </Text>
              </Button>
            )
          })}
          <Spacer />
        </HStack>
      ))
      )}
      </VStack>

      {/* Bottom spacer */}
      <Spacer minLength={4} />
    </VStack>
  )
}

// =========================
// MONTHLY VIEW (systemLarge)
// =========================

const CELL_HEIGHT = 34

function MonthlyView({ records, habits }: { records: Records, habits: string[] }) {
  const selectedName = readSelectedHabit()
  const idx = selectedName ? habits.indexOf(selectedName) : -1
  const safeIdx = idx >= 0 ? idx : 0
  const habit = habits.length > 0
    ? habits[Math.min(safeIdx, habits.length - 1)]
    : "Creatine"
  const hasPrev = habits.length > 1
  const hasNext = habits.length > 1
  const today = new Date()
  const year = today.getFullYear()
  const month = today.getMonth()
  const firstDay = new Date(year, month, 1)
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const startOffset = dayIndex(firstDay)
  const totalRows = Math.ceil((startOffset + daysInMonth) / 7)

  // Calculate cell width to fill the widget width
  const paddingTotal = 44 // 30 leading + 14 trailing
  const cellWidth = Math.floor((Widget.displaySize.width - paddingTotal) / 7)

  // Pre-compute calendar cells: null = blank, number = day of month
  const cells: (number | null)[] = []
  let dayNum = 1
  for (let i = 0; i < totalRows * 7; i++) {
    if (i < startOffset || dayNum > daysInMonth) {
      cells.push(null)
    } else {
      cells.push(dayNum)
      dayNum++
    }
  }

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ]
  const monthName = monthNames[month]

  return (
    <VStack
      padding={{ leading: 30, trailing: 14, top: 14, bottom: 10 }}
      background={{
        colors: ["#111111", "#1c1c1e"],
        startPoint: { x: 0, y: 0 },
        endPoint: { x: 0, y: 1 },
      } as LinearGradient}
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
    >
      {/* TITLE — habit name with ◀ ▶ navigation */}
      <HStack>
        {hasPrev ? (
          <Button
            buttonStyle="plain"
            frame={{ width: 30, height: 30 }}
            intent={CycleHabitIntent({ direction: "prev" })}
          >
            <Text font={16} foregroundStyle="#FF453A">◀</Text>
          </Button>
        ) : (
          <Text frame={{ width: 30, height: 30 }}>{" "}</Text>
        )}
        <Spacer />
        <Text font={10} fontWeight="bold" foregroundStyle="white">
          {habit}
        </Text>
        <Spacer />
        {hasNext ? (
          <Button
            buttonStyle="plain"
            frame={{ width: 30, height: 30 }}
            intent={CycleHabitIntent({ direction: "next" })}
          >
            <Text font={16} foregroundStyle="#FF453A">▶</Text>
          </Button>
        ) : (
          <Text frame={{ width: 30, height: 30 }}>{" "}</Text>
        )}
      </HStack>

      {/* MONTH / YEAR */}
      <Text font={18} foregroundStyle="#8E8E93">
        {monthName} {year}
      </Text>

      {/* DAY HEADER */}
      <HStack>
        {DAYS.map(d => (
          <Text
            key={d}
            frame={{ width: cellWidth, height: 16 }}
            font={9}
            fontWeight="medium"
            foregroundStyle="#8E8E93"
          >
            {d}
          </Text>
        ))}
      </HStack>

      <Spacer minLength={4} />

      {/* CALENDAR GRID */}
      <VStack spacing={2}>
      {Array.from({ length: totalRows }, (_, row) => (
        <HStack key={row}>
          {cells.slice(row * 7, row * 7 + 7).map((cell, col) => {
            if (cell === null) {
              return (
                <Text
                  key={col}
                  frame={{ width: cellWidth, height: CELL_HEIGHT }}
                >
                  {" "}
                </Text>
              )
            }

            const currentDay = new Date(year, month, cell)
            const isFuture = currentDay > today && !sameDay(currentDay, today)
            const isToday = sameDay(currentDay, today)
            const dateKey = toDateKey(currentDay)
            const done = !isFuture && isCompleted(habit, dateKey, records)

            let color: Color = "#3A3A3C"
            if (!isFuture) {
              if (done) color = "#FF453A"
              else if (isToday) color = "#8E8E93"
              else color = "#48484A"
            }

            return (
              <Button
                key={col}
                buttonStyle="plain"
                frame={{ width: cellWidth, height: CELL_HEIGHT }}
                intent={ToggleHabitIntent({ habitName: habit, dateString: dateKey })}
              >
                <Text
                  font={10}
                  foregroundStyle={color}
                >
                  {done ? "●" : "○"}
                </Text>
              </Button>
            )
          })}
        </HStack>
      ))}
      </VStack>

      <Spacer />
    </VStack>
  )
}

// =========================
// MAIN — choose view based on Widget.family
// =========================

async function main() {
  const records = loadRecords()
  const habits = loadConfiguredHabits()

  const reloadPolicy = {
    policy: "after" as const,
    date: new Date(Date.now() + 1000 * 60 * 30), // reload every 30 min
  }

  if (Widget.family === "systemLarge") {
    Widget.present(<MonthlyView records={records} habits={habits} />, { reloadPolicy })
  } else {
    // systemSmall / systemMedium → weekly view
    Widget.present(<WeeklyView records={records} habits={habits} />, { reloadPolicy })
  }
}

main()

import { AppIntentManager, AppIntentProtocol } from "scripting"
import { toggleRecordAsync, loadConfiguredHabits, writeSelectedHabitAsync, forceWidgetReload } from "./storage"

// ============ Toggle ============

/**
 * ToggleHabitIntent — runs when user taps a dot in the widget.
 */
export const ToggleHabitIntent = AppIntentManager.register({
  name: "ToggleHabit",
  protocol: AppIntentProtocol.AppIntent,
  perform: async (params: { habitName: string; dateString: string }) => {
    try {
      const newState = await toggleRecordAsync(params.habitName, params.dateString)
      console.log(`Toggled "${params.habitName}" for ${params.dateString}: ${newState ? "✓" : "○"}`)
      forceWidgetReload()
    } catch (error) {
      console.error("ToggleHabitIntent failed: " + error)
    }
  }
})

// ============ Cycle habit (monthly view) ============

/**
 * CycleHabitIntent — runs when user taps ◀/▶ in the monthly view.
 * Reads the configured habits from file and cycles the selected one.
 */
export const CycleHabitIntent = AppIntentManager.register({
  name: "CycleHabit",
  protocol: AppIntentProtocol.AppIntent,
  perform: async (params: { direction: "prev" | "next" }) => {
    try {
      const habits = loadConfiguredHabits()
      if (habits.length === 0) return

      // Read current selected habit
      const { readSelectedHabit } = await import("./storage")
      const current = readSelectedHabit()
      let currentIndex = current ? habits.indexOf(current) : -1
      if (currentIndex < 0) currentIndex = 0

      // Calculate new index
      if (params.direction === "next") {
        currentIndex = (currentIndex + 1) % habits.length
      } else {
        currentIndex = (currentIndex - 1 + habits.length) % habits.length
      }

      const newHabit = habits[currentIndex]
      await writeSelectedHabitAsync(newHabit)
      console.log(`Switched monthly view to: ${newHabit}`)
      forceWidgetReload()
    } catch (error) {
      console.error("CycleHabitIntent failed: " + error)
    }
  }
})

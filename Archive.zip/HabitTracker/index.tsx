import {
  Script, Navigation, NavigationStack, List, Section, TextField,
  Text, HStack, Button, Spacer, ToolbarItem, Toolbar, useState
} from "scripting"

// ============ Config persistence ============

const HABITS_PATH = FileManager.appGroupDocumentsDirectory + "/habits.json"

function loadHabits(): string[] {
  try {
    if (FileManager.existsSync(HABITS_PATH)) {
      const content = FileManager.readAsStringSync(HABITS_PATH, "utf8")
      const parsed = JSON.parse(content)
      if (Array.isArray(parsed)) return parsed
    }
  } catch (e) {
    console.error("loadHabits error: " + e)
  }
  return ["Pushups vs Squats", "Creatine", "Italian", "Journal"]
}

function saveHabits(habits: string[]) {
  FileManager.writeAsStringSync(
    HABITS_PATH,
    JSON.stringify(habits, null, 2),
    "utf8"
  )
}

// ============ Settings View ============

function HabitSettingsView() {
  const dismiss = Navigation.useDismiss()
  const [habits, setHabits] = useState<string[]>(loadHabits)
  const [newHabit, setNewHabit] = useState("")

  function addHabit() {
    const trimmed = newHabit.trim()
    if (trimmed && !habits.includes(trimmed)) {
      const updated = [...habits, trimmed]
      setHabits(updated)
      saveHabits(updated)
      setNewHabit("")
    }
  }

  function removeHabit(name: string) {
    const updated = habits.filter((h: string) => h !== name)
    setHabits(updated)
    saveHabits(updated)
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="Habit Tracker"
        toolbar={
          <Toolbar>
            <ToolbarItem placement="topBarLeading">
              <Button title="Close" action={dismiss} />
            </ToolbarItem>
          </Toolbar>
        }
      >
        {/* Habits list */}
        <Section title="Habits">
          {habits.length === 0 ? (
            <Text font={14} foregroundStyle="#8E8E93">
              No habits yet. Add one below.
            </Text>
          ) : (
            habits.map((habit: string) => (
              <HStack key={habit}>
                <Text>{habit}</Text>
                <Spacer />
                <Button
                  title="Delete"
                  role="destructive"
                  action={() => removeHabit(habit)}
                />
              </HStack>
            ))
          )}
        </Section>

        {/* Add new habit */}
        <Section title="Add New Habit">
          <HStack>
            <TextField
              value={newHabit}
              onChanged={setNewHabit}
              title="Habit name"
              prompt="e.g. Pushups, Creatine, Italian"
              axis="horizontal"
            />
            <Button
              title="Add"
              action={addHabit}
              disabled={!newHabit.trim()}
            />
          </HStack>
        </Section>

        {/* Widget view info */}
        <Section title="Widget Views">
          <Text font={12} foregroundStyle="#8E8E93">
            Weekly view → Add widget as systemMedium
          </Text>
          <Text font={12} foregroundStyle="#8E8E93">
            Monthly view → Add widget as systemLarge
          </Text>
        </Section>

        {/* How to use */}
        <Section title="How It Works">
          <Text font={12} foregroundStyle="#8E8E93">
            • Tapping a dot in the widget creates/updates a
            reminder in the "Routines" list.
          </Text>
          <Text font={12} foregroundStyle="#8E8E93">
            • The widget auto-refreshes every 30 minutes.
          </Text>
          <Text font={12} foregroundStyle="#8E8E93">
            • Edit this list anytime to add or remove habits.
          </Text>
        </Section>
      </List>
    </NavigationStack>
  )
}

// ============ Entry ============

async function run() {
  await Navigation.present(<HabitSettingsView />)
  Script.exit()
}

run()

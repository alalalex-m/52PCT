/**
 * Local storage for habit completion records and settings.
 * 
 * Completion records format: { "2026-05-19": ["gym", "hyd"], ... }
 */

import { Widget } from "scripting"

const RECORDS_PATH = FileManager.appGroupDocumentsDirectory + "/records.json"
const HABITS_PATH = FileManager.appGroupDocumentsDirectory + "/habits.json"

export interface Records {
  [dateKey: string]: string[]
}

// ============ Records (completion data) ============

export function loadRecords(): Records {
  try {
    if (FileManager.existsSync(RECORDS_PATH)) {
      const content = FileManager.readAsStringSync(RECORDS_PATH, "utf8")
      return JSON.parse(content)
    }
  } catch (e) {
    console.error("loadRecords error: " + e)
  }
  return {}
}

export async function saveRecordsAsync(records: Records) {
  try {
    await FileManager.writeAsString(RECORDS_PATH, JSON.stringify(records, null, 2), "utf8")
  } catch (e) {
    console.error("saveRecords error: " + e)
  }
}

/** Check if a habit was completed on a given date */
export function isCompleted(habit: string, dateKey: string, records: Records): boolean {
  const dayRecords = records[dateKey]
  if (!dayRecords) return false
  return dayRecords.includes(habit)
}

/** Toggle a habit on a date (async). Returns the new completion state (true = completed) */
export async function toggleRecordAsync(habit: string, dateKey: string): Promise<boolean> {
  const records = loadRecords()
  const dayRecords = records[dateKey] || []
  const idx = dayRecords.indexOf(habit)
  let newState: boolean
  if (idx >= 0) {
    dayRecords.splice(idx, 1)
    if (dayRecords.length === 0) {
      delete records[dateKey]
    } else {
      records[dateKey] = dayRecords
    }
    newState = false
  } else {
    dayRecords.push(habit)
    records[dateKey] = dayRecords
    newState = true
  }
  await saveRecordsAsync(records)
  return newState
}

// ============ Habits config ============

/** Load habit list from config file (set in index.tsx settings page) */
export function loadConfiguredHabits(): string[] {
  try {
    if (FileManager.existsSync(HABITS_PATH)) {
      const content = FileManager.readAsStringSync(HABITS_PATH, "utf8")
      const parsed = JSON.parse(content)
      if (Array.isArray(parsed) && parsed.length > 0) return parsed
    }
  } catch (e) {
    console.error("loadConfiguredHabits error: " + e)
  }
  return ["Pushups vs Squats", "Creatine", "Italian", "Journal"]
}

// ============ Habit selection (monthly view) ============

const SELECTED_PATH = FileManager.appGroupDocumentsDirectory + "/selected.txt"

export function readSelectedHabit(): string {
  try {
    if (FileManager.existsSync(SELECTED_PATH)) {
      return FileManager.readAsStringSync(SELECTED_PATH, "utf8").trim()
    }
  } catch (e) {
    console.error("readSelectedHabit error: " + e)
  }
  return ""
}

export async function writeSelectedHabitAsync(name: string) {
  try {
    await FileManager.writeAsString(SELECTED_PATH, name, "utf8")
  } catch (e) {
    console.error("writeSelectedHabit error: " + e)
  }
}

export function writeSelectedHabit(name: string) {
  try {
    FileManager.writeAsStringSync(SELECTED_PATH, name, "utf8")
  } catch (e) {
    console.error("writeSelectedHabit error: " + e)
  }
}

/** Force the widget to reload using all available methods */
export function forceWidgetReload() {
  Widget.reloadAll()
  Widget.reloadUserWidgets()
  Widget.reloadTestWidgets()
}

# HabitTracker — Scripting Widgets

## 概述

在 Scripting app 中运行的交互式习惯追踪小组件。

- ✅ **完全本地存储** — 不依赖 Reminders / iCloud
- ✅ **设置界面** — 在 Scripting app 中管理习惯列表
- ✅ **交互式点击** — 点击圆点切换完成状态
- ✅ **自动刷新** — 每 30 分钟自动更新

## 文件结构

```
HabitTracker/
├── widget.tsx          ← 主 widget 组件（Weekly + Monthly）
├── app_intents.tsx     ← AppIntent 定义（ToggleHabitIntent）
├── storage.tsx         ← 本地 JSON 存储（records.json）
├── index.tsx           ← 设置页面（管理习惯列表）
├── script.json         ← 项目配置
└── plan.md             ← 本文件
```

## 迁移说明

| Scriptable API | Scripting API |
|---|---|
| `await Calendar.forRemindersByTitle()` | `Calendar.forReminders()` + filter by title |
| `await Reminder.all(calendars, true)` | `Reminder.getAll(calendars)` |
| `new ListWidget()` | JSX components (`VStack`, `HStack`, `Text`) |
| `LinearGradient` | `background` prop with LinearGradient object |
| `widget.setPadding()` | `padding` prop on VStack |
| `widget.addStack()` | `HStack` / `VStack` |
| `widget.addText()` | `<Text>` |
| `Font.systemFont(x)` / `Font.mediumSystemFont(x)` | `font={x}` prop |
| `new Color("#xxx")` | hex string `"#xxx"` with `foregroundStyle` prop |
| `widget.url` | `<Link url="...">` wrapper |
| `args.widgetParameter` | `Widget.parameter` |
| `widget.presentMedium()` / `widget.presentLarge()` | `Widget.family` to auto-select view |

## Widget Families

- `systemSmall` / `systemMedium` → Weekly View
- `systemLarge` → Monthly View
- Monthly habit name comes from `Widget.parameter` (default "Creatine")

## 使用说明

### 前置条件

1. 在 iOS **Reminders（提醒事项）** 中创建一个名为 **"Routines"** 的清单
2. 在该清单中添加待办事项，标题对应习惯名（如 "Creatine"、"Pushups vs Squats" 等）
3. 给待办事项设置**截止日期**（due date），对应完成的日期
4. 完成习惯后，在 Reminders 中勾选对应项目

### 添加到主屏幕

1. 长按主屏幕进入编辑模式，点左上角 **+**
2. 搜索 **Scripting**，选择 widget
3. 选择尺寸：
   - **Medium** 或 **Small** → 显示本周四个习惯的每日追踪
   - **Large** → 显示月度日历（单习惯）
4. 编辑 Widget → 点 **Select** 选择 **HabitTracker** 脚本
5. （仅 Large）在 **Parameter** 字段输入习惯名（如 "Creatine"），留空默认追踪 Creatine
6. 点右上角 **Done** 完成

### 交互式点击

每个圆点现在是一个按钮，点击即可切换习惯完成状态：

- **点击未完成圆点（○）**：在 Reminders 中为该习惯+日期创建一个已完成提醒
- **点击已完成圆点（●）**：取消该提醒的完成状态（还原为未完成）
- 操作后 widget 自动刷新，立即显示最新状态

> 注意：未来日期的圆点不可点击（仅显示状态）

### 颜色说明

- 🔴 **红色圆点 ●**：该日已完成
- ⚫ **深灰圆点 ○**：该日未完成
- ⚪ **浅灰圆点 ○**（仅 Monthly View）：未来日期
- 🔘 **灰色圆点 ●**（仅 Monthly View）：今天未完成

### 自定义习惯列表

编辑 `widget.tsx` 第 8 行的 `HABITS` 数组：

```ts
const HABITS = ["Pushups vs Squats", "Creatine", "Italian", "Journal"]
```

改为你自己的习惯名即可。注意名称需要与 Reminders 中的标题完全一致。

### 自定义清单名

编辑 `widget.tsx` 第 7 行的 `REMINDER_LIST`：

```ts
const REMINDER_LIST = "Routines"
```

### 预览测试

在 Scripting app 中打开 HabitTracker 项目，点击 ▶️ 按钮选择 "Preview Widget"：
- Medium → 预览 Weekly View
- Large → 预览 Monthly View

### 迁移完成度

| 特性 | 原始 Scriptable | 迁移后 Scripting |
|---|---|---|
| LinearGradient 背景 | ✅ | ✅ |
| 字体粗细（medium/bold） | ✅ | ✅ |
| 行间距 | ✅ | ✅ |
| Weekly View | ✅ | ✅ |
| Monthly View | ✅ | ✅ |
| 点击跳转 Reminders | ✅ | ✅ |
| 动态 cell 宽度 | ✅ | ✅ |
| 未来日期颜色区分 | ✅ | ✅ |
| Widget Parameter | ✅ | ✅ |
| 🆕 交互式点击切换 | — | ✅ |
| 🆕 自动创建 Reminder | — | ✅ |
| 🆕 自动刷新（30min + 点击即时） | — | ✅ |

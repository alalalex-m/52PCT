import { Script } from "scripting"

// Query sleep analysis samples over a date range and summarize total sleep
// plus per-stage breakdown (inBed / asleepCore / asleepDeep / asleepREM / awake / asleepUnspecified).
const params = Script.queryParameters
const startDateStr = params.start_date as string | undefined
const endDateStr = params.end_date as string | undefined

function parseDate(raw: string, label: string): Date {
  const trimmed = raw.trim()
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    const [y, m, d] = trimmed.split("-").map(n => parseInt(n, 10))
    const date = new Date(y, m - 1, d, 0, 0, 0, 0)
    if (isNaN(date.getTime())) throw new Error(`Invalid ${label}: ${raw}`)
    return date
  }
  const spaceMatch = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/)
  if (spaceMatch) {
    const [, y, m, d, h, mi, s] = spaceMatch
    const date = new Date(
      parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10),
      parseInt(h, 10), parseInt(mi, 10), s ? parseInt(s, 10) : 0, 0,
    )
    if (isNaN(date.getTime())) throw new Error(`Invalid ${label}: ${raw}`)
    return date
  }
  const date = new Date(trimmed)
  if (isNaN(date.getTime())) throw new Error(`Invalid ${label}: ${raw}`)
  return date
}

function formatMinutes(totalMin: number): string {
  const m = Math.round(totalMin)
  if (m < 60) return `${m} min`
  const h = Math.floor(m / 60)
  const r = m % 60
  return r === 0 ? `${h} h` : `${h} h ${r} min`
}

// Matches the HealthCategoryValueSleepAnalysis enum values.
const STAGE_NAME: Record<number, string> = {
  0: "inBed",
  1: "asleepUnspecified",
  2: "awake",
  3: "asleepCore",
  4: "asleepDeep",
  5: "asleepREM",
}

// "Actually asleep" excludes inBed (usually a superset) and awake.
const ASLEEP_VALUES = new Set<number>([1, 3, 4, 5])

async function main() {
  if (!startDateStr || !endDateStr) {
    Script.exit({ success: false, error: "Missing required parameters: start_date and end_date" })
    return
  }

  try {
    if (!Health.isHealthDataAvailable) {
      Script.exit({ success: false, error: "Health data is not available on this device." })
      return
    }

    const startDate = parseDate(startDateStr, "start_date")
    const endDate = parseDate(endDateStr, "end_date")
    if (endDate.getTime() <= startDate.getTime()) {
      Script.exit({ success: false, error: `end_date (${endDateStr}) must be after start_date (${startDateStr}).` })
      return
    }

    const samples = await Health.queryCategorySamples("sleepAnalysis", {
      startDate, endDate,
      sortDescriptors: [{ key: "startDate", order: "forward" }],
    })

    // Aggregate stage durations (minutes).
    const stageMinutes: Record<string, number> = {
      inBed: 0,
      asleepUnspecified: 0,
      awake: 0,
      asleepCore: 0,
      asleepDeep: 0,
      asleepREM: 0,
    }
    let asleepMinutes = 0

    for (const s of samples) {
      const durMs = s.endDate.getTime() - s.startDate.getTime()
      if (durMs <= 0) continue
      const durMin = durMs / 60000
      const name = STAGE_NAME[s.value] ?? "unknown"
      if (!(name in stageMinutes)) stageMinutes[name] = 0
      stageMinutes[name] += durMin
      if (ASLEEP_VALUES.has(s.value)) asleepMinutes += durMin
    }

    // Count distinct sleep sessions: collapse consecutive samples with gap < 1h.
    const sortedSamples = [...samples].sort((a, b) => a.startDate.getTime() - b.startDate.getTime())
    let sessions = 0
    let lastEnd = -Infinity
    for (const s of sortedSamples) {
      if (s.startDate.getTime() - lastEnd > 60 * 60 * 1000) sessions++
      lastEnd = Math.max(lastEnd, s.endDate.getTime())
    }

    const stageFormatted: Record<string, string> = {}
    const stageRounded: Record<string, number> = {}
    for (const [k, v] of Object.entries(stageMinutes)) {
      stageRounded[k] = Math.round(v)
      stageFormatted[k] = formatMinutes(v)
    }

    Script.exit({
      success: true,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      sampleCount: samples.length,
      sessionCount: sessions,
      totalAsleepMinutes: Math.round(asleepMinutes),
      totalAsleepFormatted: formatMinutes(asleepMinutes),
      stageMinutes: stageRounded,
      stageFormatted,
    })
  } catch (error: any) {
    Script.exit({ success: false, error: error?.message ?? String(error) })
  }
}

main()

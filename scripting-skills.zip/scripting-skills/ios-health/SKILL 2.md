---
name: ios-health
description: Query iOS Health data — retrieve health metrics from HealthKit such as step count, distance, active energy, exercise time, heart rate, sleep analysis, daily activity ring summaries, workout sessions, and a combined today snapshot.
runtime: node
metadata:
  display_name: "iOS Health"
  required_tools: "run_shell_command"
---

# Purpose

This skill provides scripts for querying iOS Health (HealthKit) data through the Scripting TypeScript runtime. Use it when the user wants to read health metrics over a date range.

Each script is **purpose-built** for a single metric or concept. Parameters are kept intentionally minimal — units and aggregation semantics are fixed internally per metric, so callers don't need to know HealthKit internals.

# Permissions

The underlying `Health.*` APIs prompt the user (first time) to grant Read access to the requested data types via the system permission sheet. If access is denied:
- Quantity / category queries return **empty results** (no thrown error).
- Profile reads (date of birth, etc.) **reject** the promise.

If `Health.isHealthDataAvailable` is false (e.g. iPad without Health), all scripts exit with `{ success: false, error: ... }`.

Manual path: **Health app → Data Access & Devices → Scripting** → enable the needed data types.

# Common Conventions

All scripts share these rules:
- **Date parsing**: accepts `YYYY-MM-DD` (treated as local midnight), `YYYY-MM-DD HH:mm:ss` (local time), or ISO 8601.
- **`end_date` is exclusive at day granularity**: to query April 1–14 inclusive, pass `end_date: "2026-04-15"`.
- **Units are fixed per script** (no `unit` parameter). See each script's output description.
- **Output envelope**:
  - Success: `{ success: true, startDate, endDate, ...metricFields }`
  - Failure: `{ success: false, error: "<message>" }`
- Each script returns both raw numeric fields and a human-readable `formatted` string.

All scripts are executed via `run_shell_command` using `scripting-ts run <path> --queryparameters '<json>'`.

# Available Scripts

## 1. query_step_count.ts — Step count

Cumulative step count over a range, optional daily breakdown.

```
scripting-ts run <skill_dir>/scripts/query_step_count.ts --queryparameters '{"start_date":"2026-04-01","end_date":"2026-04-15","daily":true}'
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `start_date` | string | ✅ | Start (inclusive). |
| `end_date` | string | ✅ | End (exclusive). |
| `daily` | boolean | ❌ | If true, include per-day breakdown. Default: false. |

**Output:** `totalSteps: number`, optional `daily: [{date, steps}]`.

## 2. query_distance.ts — Walking + running distance (km)

```
scripting-ts run <skill_dir>/scripts/query_distance.ts --queryparameters '{"start_date":"2026-04-01","end_date":"2026-04-15","daily":true}'
```

**Parameters:** same as #1.

**Output:** `totalKm: number`, `formatted: "12.34 km"`, optional `daily: [{date, km, formatted}]`. Fixed unit: kilometer.

## 3. query_active_energy.ts — Active energy (kcal)

```
scripting-ts run <skill_dir>/scripts/query_active_energy.ts --queryparameters '{"start_date":"2026-04-01","end_date":"2026-04-15","daily":true}'
```

**Parameters:** same as #1.

**Output:** `totalKcal: number`, `formatted: "2341 kcal"`, optional `daily`. Fixed unit: kilocalorie.

## 4. query_exercise_time.ts — Apple Exercise Time (minutes)

```
scripting-ts run <skill_dir>/scripts/query_exercise_time.ts --queryparameters '{"start_date":"2026-04-01","end_date":"2026-04-15","daily":true}'
```

**Parameters:** same as #1.

**Output:** `totalMinutes: number`, `formatted: "3 h 25 min"`, optional `daily`. Fixed unit: minute.

## 5. query_heart_rate.ts — Heart rate (bpm)

Discrete metric — returns average, min, max, and most recent.

```
scripting-ts run <skill_dir>/scripts/query_heart_rate.ts --queryparameters '{"start_date":"2026-04-13","end_date":"2026-04-14"}'
```

**Parameters:**
| Name | Type | Required |
|------|------|----------|
| `start_date` | string | ✅ |
| `end_date` | string | ✅ |

**Output:** `averageBpm`, `minBpm`, `maxBpm`, `mostRecentBpm`, `mostRecentAt` (ISO), plus `formatted: {average, min, max, mostRecent}`. Fixed unit: count/minute (bpm).

## 6. query_sleep.ts — Sleep analysis

Aggregates `sleepAnalysis` category samples into total time asleep plus per-stage breakdown.

```
scripting-ts run <skill_dir>/scripts/query_sleep.ts --queryparameters '{"start_date":"2026-04-13","end_date":"2026-04-14"}'
```

**Parameters:** same as #5.

**Output:**
- `sampleCount`, `sessionCount` (distinct sleep sessions, gap >1h)
- `totalAsleepMinutes`, `totalAsleepFormatted` — sums `asleepCore + asleepDeep + asleepREM + asleepUnspecified`, excludes `inBed` and `awake`.
- `stageMinutes` and `stageFormatted` — per-stage totals for `inBed`, `awake`, `asleepCore`, `asleepDeep`, `asleepREM`, `asleepUnspecified`.

**Note:** `inBed` typically overlaps with the asleep stages (it's a superset). Don't add it to the asleep total.

## 7. query_activity_summary.ts — Activity rings (Move / Exercise / Stand)

Daily Move, Exercise, and Stand ring values with goals and completion percentages.

```
scripting-ts run <skill_dir>/scripts/query_activity_summary.ts --queryparameters '{"start_date":"2026-04-08","end_date":"2026-04-15"}'
```

**Parameters:** same as #5.

**Output:**
- `dayCount`, `daily: [...]`
- Each day has: `date`, `moveMode` (`activeEnergy`|`appleMoveTime`), and three rings:
  - `move: { actual, goal, unit, percent, formatted }` — unit depends on `moveMode` (kcal vs minute)
  - `exercise: { minutes, goalMinutes, percent, formatted }`
  - `stand: { hours, goalHours, percent, formatted }`

## 8. query_workouts.ts — Workout sessions

List individual workout sessions (running, walking, strength training, etc.) in a date range, with per-workout stats.

```
scripting-ts run <skill_dir>/scripts/query_workouts.ts --queryparameters '{"start_date":"2026-04-08","end_date":"2026-04-15","limit":50}'
```

**Parameters:**
| Name | Type | Required | Description |
|------|------|----------|-------------|
| `start_date` | string | ✅ | Start (inclusive). |
| `end_date` | string | ✅ | End (exclusive). |
| `limit` | number | ❌ | Max workouts to return. Default: 50. Results sorted newest-first. |

**Output:**
- `count`, `totals: { durationMinutes, durationFormatted, kcal, km }`
- `workouts: [...]` — each item has:
  - `uuid`, `activityType` (numeric), `activityName` (human-readable, e.g. `"Walking"`, `"Traditional Strength Training"`)
  - `startDate`, `endDate`, `durationMinutes`, `durationFormatted`
  - `distanceKm` (null for non-distance activities like strength training)
  - `kcal`, `avgHeartRateBpm`, `maxHeartRateBpm` (null if unavailable)
  - `source` (recording device/app name, e.g. `"Apple Watch"`)
  - `formatted` — one-line summary string

## 9. query_today_snapshot.ts — Today at a glance

A combined one-shot overview of today's health data. All sub-queries run in parallel so HealthKit shows a single merged permission prompt.

```
scripting-ts run <skill_dir>/scripts/query_today_snapshot.ts --queryparameters '{}'
```

**Parameters:** none.

**Output:**
- `asOf`, `dayStart`, `dayEnd` (ISO timestamps)
- `today: { steps, distanceKm, activeKcal, exerciseMinutes, flightsClimbed, formatted: {...} }`
- `heartRate: { latestBpm, latestAt, restingBpm, restingAt }` — latest reading within 24h, resting within 7 days
- `rings`: same shape as `query_activity_summary.ts` for today, or `null` if no summary
- `sleepLastNight`: sleep session within the last ~18h window — `{ sessionStart, sessionEnd, totalAsleepMinutes, totalAsleepFormatted, stageMinutes }`, or `null` if no sleep samples

# Instructions

1. Pick the script that matches the user's question:
   - **Quick overview** of today → `query_today_snapshot.ts` (no args needed)
   - **Single metric over a range** → step count / distance / active energy / exercise time
   - **Heart rate** → `query_heart_rate.ts`
   - **Sleep** → `query_sleep.ts`
   - **Activity rings by day** → `query_activity_summary.ts`
   - **Workout sessions list** → `query_workouts.ts`
2. Clarify the date range. Remember `end_date` is **exclusive at day granularity** — add +1 day if the user names an inclusive end date.
3. For cumulative metrics (#1–#4), ask whether they want a daily breakdown (`daily: true`) or just a total.
4. Build the `--queryparameters` JSON and invoke via `run_shell_command`.
5. Parse the JSON and summarize using the `formatted` fields. For `daily` output, highlight totals, averages, and peak days.
6. On `success: false`, surface the error and suggest checking Health permissions for the Scripting app.

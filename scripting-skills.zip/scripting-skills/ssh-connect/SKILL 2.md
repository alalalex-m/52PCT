---
name: ssh-connect
description: Guide for configuring and using SSH connections in iOS Scripting environment. Explains key-based authentication requirements and provides helper scripts.
metadata:
  display_name: "SSH Connect"
  intent_patterns: "ssh connect, ssh server, remote server, ssh key, generate ssh key, ssh config, ios_popen failed"
  required_tools: "run_shell_command"
---

# Purpose

Use this skill when the user wants to:
- Connect to a remote server via SSH
- Generate SSH keys
- Troubleshoot SSH connection issues (especially `ios_popen failed`)
- Execute commands on remote servers

# Background

iOS 上通过 `ios_system` 调用的 SSH（OpenSSH 8.5p1）有以下限制：

1. **无法使用密码认证** - 交互式输入会导致 `ios_popen failed`
2. **必须使用密钥认证** - 配合 `-T` 禁用伪终端
3. **`/etc/ssh/` 不存在** - 这是正常的，不影响功能
4. **SSH_HOME 环境变量** - 指向 app 沙盒内的 Documents 目录

# Instructions

## 关键参数

连接时**必须**使用以下参数组合：

```bash
ssh -T -o BatchMode=yes -o StrictHostKeyChecking=no -i <密钥路径> user@host "命令"
```

| 参数 | 说明 |
|------|------|
| `-T` | 禁用伪终端分配（**必需**，否则 ios_popen failed） |
| `-o BatchMode=yes` | 批处理模式，不提示密码 |
| `-o StrictHostKeyChecking=no` | 自动接受新主机密钥 |
| `-i <key>` | 指定私钥文件 |

## 使用流程

> **核心原则**：**先直接尝试连接**。如果本机已经有密钥、服务器也已授权，通常可以一次性连通，无需经历"生成密钥 → 部署公钥"等繁琐步骤。只有在连接失败时才回退到后续步骤。

### Step 1（**必做，优先**）: 直接尝试连接

**无论是否知道历史配置，agent 的第一个动作都应该是执行下面这条命令**：

```bash
ssh -T -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=10 user@host "echo connected"
```

- ✅ **输出 `connected`** → 连接正常，**直接跳到 Step 5 执行远程命令**，Step 2/3/4 全部跳过。
- ❌ **输出 `Permission denied (publickey)`** → 密钥未授权，进入 Step 2。
- ❌ **输出 `ios_popen failed`** → 命令参数有误（缺 `-T` 或 `BatchMode=yes`），修正后重试。
- ❌ **输出 `Connection refused / timed out`** → 网络/端口/防火墙问题，与密钥无关。
- ❌ **输出 `Host key verification failed`** → 加 `-o StrictHostKeyChecking=no` 重试。

### Step 2（仅在 Step 1 因密钥失败时执行）: 检查本地密钥

```bash
echo "SSH_HOME: $SSH_HOME" && ls -la $SSH_HOME/.ssh/ 2>/dev/null
```

若已有 `id_ed25519` / `id_rsa`，跳过 Step 3。

### Step 3（仅在无密钥时执行）: 生成密钥

```bash
ssh-keygen -t ed25519 -f $SSH_HOME/.ssh/id_ed25519 -N "" -q
cat $SSH_HOME/.ssh/id_ed25519.pub
```

### Step 4（仅在 Step 1 失败时执行）: 部署公钥到服务器

**需要用户手动操作**（因为此时无法自动登录）：把公钥追加到服务器：

```bash
mkdir -p ~/.ssh && chmod 700 ~/.ssh
echo '<公钥内容>' >> ~/.ssh/authorized_keys
chmod 600 ~/.ssh/authorized_keys
```

部署完成后回到 Step 1 重试。

### Step 5: 执行远程命令

```bash
ssh -T -o BatchMode=yes -o ConnectTimeout=10 user@host "要执行的命令"
```

## 常见问题

### Q: `ios_popen failed`
**A:** 缺少 `-T` 参数，或尝试使用密码认证。必须用密钥认证 + `-T`。

### Q: `Permission denied (publickey)`
**A:** 服务器未配置公钥。需要将公钥添加到服务器的 `~/.ssh/authorized_keys`。

### Q: `Host key verification failed`
**A:** 添加 `-o StrictHostKeyChecking=no` 参数。

### Q: 密钥在哪里？
**A:** `$SSH_HOME/.ssh/` 目录下。默认使用 `id_ed25519` 或 `id_rsa`。

## 示例：Agent 使用 SSH

**推荐流程：先试连通，通了直接用，不通再排查。**

```bash
# 1. 【第一步永远是这个】直接尝试连接
ssh -T -o BatchMode=yes -o StrictHostKeyChecking=no -o ConnectTimeout=10 root@1.2.3.4 "echo connected"

# 如果输出 connected，跳到第 4 步。

# 2. 仅在第 1 步因 publickey 被拒时：检查并生成密钥
ls $SSH_HOME/.ssh/
ssh-keygen -t ed25519 -f $SSH_HOME/.ssh/id_ed25519 -N "" -q
cat $SSH_HOME/.ssh/id_ed25519.pub   # 让用户把公钥添加到服务器

# 3. 用户完成授权后重试第 1 步

# 4. 连通后执行所需命令
ssh -T -o BatchMode=yes -o ConnectTimeout=10 root@1.2.3.4 "uname -a && df -h"
```

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `scripts/check-ssh-status.sh` | 检查 SSH 环境配置状态 |
| `scripts/generate-key.sh` | 生成新的 SSH 密钥对 |
| `scripts/test-connection.sh` | 测试 SSH 连接是否正常 |
